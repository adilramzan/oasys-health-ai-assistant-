//
//  View+Extensions.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 21/01/2026.
//

extension String {
    
    /// Removes stars, backslashes, and extra newlines from AI text
    var cleanedForChat: String {
        self
            .replacingOccurrences(of: "*", with: "")     // remove stars
            .replacingOccurrences(of: "\\n", with: " ") // replace literal \n with space
            .replacingOccurrences(of: "\n", with: " ")  // replace actual newlines with space
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
}
