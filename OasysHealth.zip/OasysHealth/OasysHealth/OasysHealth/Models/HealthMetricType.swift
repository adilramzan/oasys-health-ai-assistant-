//
//  HealthMetricType.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation

enum HealthMetricType: String, CaseIterable, Identifiable {
    case steps
    case heartRate
    case sleepHours
    case activeEnergy
    case exerciseMinutes

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .steps: return "Steps"
        case .heartRate: return "Heart Rate"
        case .sleepHours: return "Sleep"
        case .activeEnergy: return "Active Energy"
        case .exerciseMinutes: return "Exercise"
        }
    }

    var unit: String {
        switch self {
        case .steps: return "steps"
        case .heartRate: return "bpm"
        case .sleepHours: return "hrs"
        case .activeEnergy: return "kcal"
        case .exerciseMinutes: return "min"
        }
    }
}
