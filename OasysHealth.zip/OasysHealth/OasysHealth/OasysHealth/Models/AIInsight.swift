//
//  AIInsight.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation

struct AIInsight: Identifiable,Equatable {
    let id = UUID()
    let title: String
    let summary: String
    let generatedAt: Date
}
