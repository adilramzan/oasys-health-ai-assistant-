//
//  MainTabView.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import SwiftUI

struct MainTabView: View {
    @StateObject private var vm = MainTabViewModel()

//    var body: some View {
//        Group {
//            if vm.isLoading {
//                ProgressView("Requesting Health Access...")
//                    .tint(.blue)
//            } else if vm.isAuthorized {
//                tabView
//            } else {
//                permissionView
//            }
//        }
//        .alert("Error", isPresented: .constant(vm.errorMessage != nil)) {
//            Button("OK") { vm.errorMessage = nil }
//        } message: {
//            Text(vm.errorMessage ?? "")
//        }
//        .ignoresSafeArea(.all) // Makes the view fullscreen
//    }
    var body: some View {
        ZStack {
            if vm.isLoading {
                ProgressView("Requesting Health Access...")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if vm.isAuthorized {
                tabView
            } else {
                permissionView
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .edgesIgnoringSafeArea(.all)
        .alert("Error", isPresented: .constant(vm.errorMessage != nil)) {
            Button("OK") { vm.errorMessage = nil }
        } message: {
            Text(vm.errorMessage ?? "")
        }
    }


    // MARK: - Tabs
    private var tabView: some View {
        TabView {
            HealthAnalysisView()
                .tabItem {
                    Label("Analysis", systemImage: "brain.head.profile")
                }

            HealthChartView()
                .tabItem {
                    Label("Charts", systemImage: "chart.line.uptrend.xyaxis")
                }
        }
        .accentColor(.blue)
    }

    // MARK: - Permission View
    private var permissionView: some View {
        ZStack {
            Color.blue.opacity(0.1)
                .ignoresSafeArea()
            VStack(spacing: 20) {
                Image(systemName: "heart.fill")
                    .font(.system(size: 48))
                    .foregroundColor(.blue)

                Text("Health Access Required")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.blue)

                Text("Oasys Health analyzes your health data to provide personalized insights.")
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)

                Button {
                    vm.requestHealthPermission()
                } label: {
                    Text("Allow Health Access")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.blue)
            }
            .padding()
        }
    }
}

#Preview {
    MainTabView()
}

