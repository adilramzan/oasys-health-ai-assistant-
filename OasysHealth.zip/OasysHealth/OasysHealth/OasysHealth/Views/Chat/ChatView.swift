//
//  ChatView.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation
import SwiftUI

struct ChatView: View {

    @ObservedObject var vm: ChatViewModel
    @State private var inputText = ""

    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(spacing: 8) {
                        ForEach(vm.messages) { msg in
                            ChatBubbleView(message: msg)
                        }
                    }
                    .padding()
                    .onChange(of: vm.messages.count) { _ in
                        if let last = vm.messages.last {
                            proxy.scrollTo(last.id, anchor: .bottom)
                        }
                    }
                    
                }
            }

            HStack {
                TextField("Ask about your health...", text: $inputText)
                    .textFieldStyle(.roundedBorder)

                Button {
                    guard !inputText.isEmpty else { return }
                    vm.sendMessage(inputText)
                    inputText = ""
                } label: {
                    Image(systemName: "paperplane.fill")
                        .rotationEffect(.degrees(45))
                        .font(.title2)
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 8)
        }
        .background(Color(.systemGray6))
        
    }
}
