//
//  ChatBubbleView.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation
import SwiftUI

struct ChatBubbleView: View {

    let message: ChatMessage

    var body: some View {
        HStack {
            if message.isUser { Spacer() }
            
            Text(message.text.cleanedForChat)
                .padding()
                .background(message.isUser ? Color.blue : Color.gray.opacity(0.3))
                .foregroundColor(message.isUser ? .white : .primary)
                .cornerRadius(16)
                .frame(maxWidth: 250, alignment: message.isUser ? .trailing : .leading)


            if !message.isUser { Spacer() }
        }
        .id(message.id)
        .padding(message.isUser ? .leading : .trailing, 50)
        
    }
}
