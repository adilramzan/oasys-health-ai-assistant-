//
//  InsightCardView.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation
import SwiftUI

struct InsightCardView: View {

    let insight: AIInsight

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(insight.title)
                .font(.headline)
            Text(insight.summary)
                .font(.subheadline)
                .foregroundColor(.secondary)
            Text(insight.generatedAt, style: .time)
                .font(.caption)
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(12)
        .shadow(radius: 1)
        
        
    }
}
