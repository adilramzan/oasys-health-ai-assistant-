//
//  LoadingView.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation
import SwiftUI

struct LoadingView: View {
    var body: some View {
        VStack(spacing: 16) {
            ProgressView()
            Text("Fetching your health insights...")
                .foregroundColor(.secondary)
        }
        .padding()
    }
}
