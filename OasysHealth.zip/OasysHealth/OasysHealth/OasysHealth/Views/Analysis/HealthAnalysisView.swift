//
//  HealthAnalysisView.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation
import SwiftUI

struct HealthAnalysisView: View {

    @StateObject private var vm = HealthAnalysisViewModel(apiKey: "") // put API key here in string
    @StateObject private var chatVM = ChatViewModel(apiKey: "") // put API key here in string

    var body: some View {
        NavigationView {
            VStack {
                if vm.isLoading {
                    LoadingView()
                } else {
                    ScrollView {
                        VStack(spacing: 16) {
                            ForEach(vm.insights) { insight in
                                InsightCardView(insight: insight)
                            }
                        }
                        .padding()
                    }
                }

                ChatView(vm: chatVM)
                    .frame(height: 300)
            }
            .navigationTitle("Health Analysis")
            .onAppear {
                vm.fetchHealthInsights()
            }
            .onChange(of: vm.insights) { newInsights in
                chatVM.updateInsights(newInsights)
            }
            
            .alert("Error", isPresented: .constant(vm.errorMessage != nil)) {
                Button("OK") { vm.errorMessage = nil }
            } message: {
                Text(vm.errorMessage ?? "")
            }
        }
        
    }
}
