//
//  MetricPickerView.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation
import SwiftUI

struct MetricPickerView: View {

    @Binding var selectedMetric: HealthMetricType

    var body: some View {
        Picker("Metric", selection: $selectedMetric) {
            ForEach(HealthMetricType.allCases) { type in
                Text(type.displayName).tag(type)
            }
        }
        .pickerStyle(.segmented)
        .padding(.horizontal)
        
        
    }
}
