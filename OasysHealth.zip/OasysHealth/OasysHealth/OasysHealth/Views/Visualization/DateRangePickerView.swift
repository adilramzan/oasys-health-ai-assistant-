//
//  DateRangePickerView.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation
import SwiftUI

struct DateRangePickerView: View {

    @Binding var selectedDays: Int
    let options: [Int]

    var body: some View {
        Picker("Date Range", selection: $selectedDays) {
            ForEach(options, id: \.self) { days in
                Text("Last \(days) Days").tag(days)
            }
        }
        .pickerStyle(.segmented)
        .padding(.horizontal)
        
    }
}
