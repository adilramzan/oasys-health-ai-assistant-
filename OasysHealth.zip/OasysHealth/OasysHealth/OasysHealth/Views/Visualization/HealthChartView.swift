//
//  HealthChartView.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation
import SwiftUI
import Charts

struct HealthChartView: View {

    @StateObject private var vm = HealthChartViewModel()

    private let dayOptions = [7, 14, 30]

    var body: some View {
        NavigationView {
            VStack {
                if vm.isLoading {
                    ProgressView("Loading metrics...")
                        .padding()
                } else {
                    VStack(spacing: 16) {
                        // Metric Picker
                        MetricPickerView(selectedMetric: $vm.selectedMetric)
                            .onChange(of: vm.selectedMetric) { _ in vm.filterMetrics() }

                        // Date Range Picker
                        DateRangePickerView(selectedDays: $vm.selectedDays, options: dayOptions)
                            .onChange(of: vm.selectedDays) { _ in vm.fetchMetrics(days: vm.selectedDays) }

                        // Chart
                        if vm.filteredMetrics.isEmpty {
                            Text("No data available for \(vm.selectedMetric.displayName)")
                                .foregroundColor(.secondary)
                                .padding()
                        } else {
                            LineChartView(metrics: vm.filteredMetrics)
                                .frame(height: 300)
                                .padding()
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("Health Charts")
            .onAppear { vm.fetchMetrics() }
            .alert("Error", isPresented: .constant(vm.errorMessage != nil)) {
                Button("OK") { vm.errorMessage = nil }
            } message: {
                Text(vm.errorMessage ?? "")
            }
        }
        
    }
}
