//
//  AppCoordinator.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import SwiftUI

struct AppCoordinator: View {
    var body: some View {
        
        MainTabView()

    }
}

#Preview {
    AppCoordinator()
}
