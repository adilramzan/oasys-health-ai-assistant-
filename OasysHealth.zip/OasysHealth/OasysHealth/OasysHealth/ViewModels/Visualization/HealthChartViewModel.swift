//
//  HealthChartViewModel.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation
import SwiftUI

@MainActor
final class HealthChartViewModel: ObservableObject {

    @Published var allMetrics: [HealthMetric] = []
    @Published var filteredMetrics: [HealthMetric] = []
    @Published var selectedMetric: HealthMetricType = .steps
    @Published var selectedDays: Int = 7
    @Published var isLoading = false
    @Published var errorMessage: String?

    private let healthService = HealthKitService.shared
    
    func fetchMetrics(days: Int? = nil) {
        Task {
            do {
                isLoading = true
                let daysToFetch = days ?? selectedDays
                
                // fetching real HealthKit data
                let realMetrics = try await healthService.fetchAllMetrics(days: daysToFetch)
                
                // If empty, use mock data
                allMetrics = realMetrics.isEmpty ? MockHealthData.generateMetrics(days: daysToFetch) : realMetrics
                
                filterMetrics()
            } catch {
                // If HealthKit fails, fall back to mock data
                allMetrics = MockHealthData.generateMetrics(days: days ?? selectedDays)
                filterMetrics()
                errorMessage = error.localizedDescription
            }
            isLoading = false
        }
    }


    func filterMetrics() {
        filteredMetrics = allMetrics.filter { $0.type == selectedMetric }
        filteredMetrics.sort { $0.date < $1.date }
    }

    func selectMetric(_ type: HealthMetricType) {
        selectedMetric = type
        filterMetrics()
    }

    func selectDays(_ days: Int) {
        selectedDays = days
        fetchMetrics(days: days)
    }
}
