//
//  MainTabViewModel.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation

@MainActor
final class MainTabViewModel: ObservableObject {

    @Published var isAuthorized = false
    @Published var isLoading = false
    @Published var errorMessage: String?

    private let healthService = HealthKitService.shared

    func requestHealthPermission() {
        Task {
            do {
                isLoading = true
                try await healthService.requestPermission()
                isAuthorized = true
            } catch {
                errorMessage = error.localizedDescription
            }
            isLoading = false
        }
    }
}
