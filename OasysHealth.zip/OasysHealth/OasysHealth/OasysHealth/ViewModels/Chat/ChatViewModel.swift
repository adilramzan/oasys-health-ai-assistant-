//
//  ChatViewModel.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation

//@MainActor
//final class ChatViewModel: ObservableObject {
//
//    @Published var messages: [ChatMessage] = []
//    @Published var isSending = false
//    @Published var errorMessage: String?
//
//    private let aiService: LLMServiceProtocol
//    private var insights: [AIInsight] = []
//
//    init(
//        insights: [AIInsight] = [],
//        aiService: LLMServiceProtocol = OpenAIService()
//    ) {
//        self.insights = insights
//        self.aiService = aiService
//    }
//
//    func updateInsights(_ insights: [AIInsight]) {
//        self.insights = insights
//    }
//    
//    func sendMessage(_ text: String) {
//        let userMessage = ChatMessage(text: text, isUser: true, date: Date())
//        let historyBeforeSend = messages   // snapshot BEFORE append
//
//        messages.append(userMessage)
//
//        Task {
//            do {
//                isSending = true
//                let aiReply = try await aiService.sendChatMessage(
//                    text,
//                    history: historyBeforeSend,
//                    insights: insights 
//                )
//                messages.append(aiReply)
//            } catch {
//                errorMessage = error.localizedDescription
//            }
//            isSending = false
//        }
//    }
//    
//
//}

@MainActor
final class ChatViewModel: ObservableObject {

    @Published var messages: [ChatMessage] = []
    @Published var isSending = false
    @Published var errorMessage: String?

    private let aiService: LLMServiceProtocol
    private let healthService = HealthKitService.shared

    private var insights: [AIInsight] = [] // Store insights from HealthAnalysisView
    
    // your modal name
    let geminiModel = "gemini-2.5-flash-lite"
    
    init(apiKey: String) {
        self.aiService = GeminiService(apiKey: apiKey, model: geminiModel)
    }

    // Update insights from HealthAnalysisView
    func updateInsights(_ newInsights: [AIInsight]) {
        insights = newInsights
    }

    func sendMessage(_ text: String) {
        let userMessage = ChatMessage(text: text, isUser: true, date: Date())
        let historyBeforeSend = messages
        messages.append(userMessage)

        Task {
            do {
                isSending = true

                // Use stored insights, fallback to HealthKit if empty
                let currentInsights: [AIInsight]
                if insights.isEmpty {
                    let metrics = try await healthService.fetchAllMetrics(days: 7)
                    currentInsights = try await aiService.analyzeHealthData(metrics)
                    insights = currentInsights
                } else {
                    currentInsights = insights
                }

                let aiReply = try await aiService.sendChatMessage(
                    text,
                    history: historyBeforeSend,
                    insights: currentInsights
                )
                
                // log for ai response
                print("🟢 AI Reply:", aiReply.text)


                messages.append(aiReply)
            } catch {
                errorMessage = error.localizedDescription
            }
            isSending = false
        }
    }
}
