//
//  HealthAnalysisViewModel.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation

//@MainActor
//final class HealthAnalysisViewModel: ObservableObject {
//
//    @Published var insights: [AIInsight] = []
//    @Published var isLoading = false
//    @Published var errorMessage: String?
//
//    private let healthService = HealthKitService.shared
//    private let aiService: LLMServiceProtocol
//
//    init(aiService: LLMServiceProtocol = OpenAIService()) {
//        self.aiService = aiService
//    }
//
//    func fetchHealthInsights(days: Int = 7) {
//        Task {
//            do {
//                isLoading = true
//
//                let realMetrics = try await healthService.fetchAllMetrics(days: days)
//
//                let finalMetrics: [HealthMetric]
//                if realMetrics.isEmpty {
//                    print("⚠️ HealthKit empty → using mock data for AI")
//                    finalMetrics = MockHealthData.generateMetrics(days: days)
//                } else {
//                    finalMetrics = realMetrics
//                }
//
//                insights = try await aiService.analyzeHealthData(finalMetrics)
//
//            } catch {
//                print("❌ HealthKit failed → using mock data for AI")
//                let mock = MockHealthData.generateMetrics(days: days)
//                insights = (try? await aiService.analyzeHealthData(mock)) ?? []
//                errorMessage = error.localizedDescription
//            }
//
//            isLoading = false
//        }
//    }
//}


@MainActor
final class HealthAnalysisViewModel: ObservableObject {

    @Published var insights: [AIInsight] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    private let healthService = HealthKitService.shared
    private let aiService: LLMServiceProtocol
    
    // your modal name
    let geminiModel = "gemini-2.5-flash-lite"
    
    // GeminiService, instead of OpenAIService
    init(apiKey: String) {
        self.aiService = GeminiService(apiKey: apiKey, model: geminiModel)
    }

    func fetchHealthInsights(days: Int = 7) {
        Task {
            do {
                isLoading = true

                let realMetrics = try await healthService.fetchAllMetrics(days: days)

                let finalMetrics: [HealthMetric]
                if realMetrics.isEmpty {
                    print("⚠️ HealthKit empty → using mock data for AI")
                    finalMetrics = MockHealthData.generateMetrics(days: days)
                } else {
                    finalMetrics = realMetrics
                }

                insights = try await aiService.analyzeHealthData(finalMetrics)

            } catch {
                print("❌ HealthKit failed → using mock data for AI")
                let mock = MockHealthData.generateMetrics(days: days)
                insights = (try? await aiService.analyzeHealthData(mock)) ?? []
                errorMessage = error.localizedDescription
            }

            isLoading = false
        }
    }
}
