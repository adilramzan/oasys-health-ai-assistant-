//
//  MockHealthData.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 20/01/2026.
//

import Foundation

struct MockHealthData {
    static func generateMetrics(days: Int = 7) -> [HealthMetric] {
        let now = Date()
        var metrics: [HealthMetric] = []

        for i in 0..<days {
            let date = Calendar.current.date(byAdding: .day, value: -i, to: now)!
            metrics.append(contentsOf: [
                HealthMetric(type: .steps, value: Double(Int.random(in: 4000...12000)), date: date, unit: "steps"),
                HealthMetric(type: .heartRate, value: Double(Int.random(in: 60...100)), date: date, unit: "bpm"),
                HealthMetric(type: .sleepHours, value: Double.random(in: 5...9), date: date, unit: "hrs"),
                HealthMetric(type: .activeEnergy, value: Double(Int.random(in: 300...700)), date: date, unit: "kcal"),
                HealthMetric(type: .exerciseMinutes, value: Double(Int.random(in: 20...60)), date: date, unit: "min")
            ])
        }

        return metrics
    }
}
