//
//  LineChartView.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation
import SwiftUI
import Charts

struct LineChartView: View {

    let metrics: [HealthMetric]

    var body: some View {
        Chart(metrics) { metric in
            LineMark(
                x: .value("Date", metric.date, unit: .day),
                y: .value("Value", metric.value)
            )
            .foregroundStyle(.blue)
            .interpolationMethod(.catmullRom)
            PointMark(
                x: .value("Date", metric.date),
                y: .value("Value", metric.value)
            )
            .foregroundStyle(.blue)
        }
        .chartXAxis {
            AxisMarks(values: .automatic(desiredCount: 5)) { value in
                AxisValueLabel(format: .dateTime.day().month())
            }
        }
        .chartYAxis {
            AxisMarks(position: .leading)
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(12)
    }
}
