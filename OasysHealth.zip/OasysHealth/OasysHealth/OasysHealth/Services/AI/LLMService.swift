//
//  LLMService.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation

protocol LLMServiceProtocol {
    func analyzeHealthData(_ metrics: [HealthMetric]) async throws -> [AIInsight]
    func sendChatMessage(_ message: String, history: [ChatMessage], insights: [AIInsight]) async throws -> ChatMessage
}

// with mock data
//protocol LLMServiceProtocol {
//    func analyzeHealthData(_ metrics: [HealthMetric]) async throws -> [AIInsight]
//    func sendChatMessage(
//        _ message: String,
//        history: [ChatMessage],
//        insights: [AIInsight]
//    ) async throws -> ChatMessage
//}
