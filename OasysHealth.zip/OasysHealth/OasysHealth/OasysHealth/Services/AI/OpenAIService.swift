//
//  OpenAIService.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation

// WITH MOCK DATA
//final class OpenAIService: LLMServiceProtocol {
//
//    private let apiKey = "AIzaSyB1xdXAo2Imaix0Z-NR2v8SBy4BSIc7Hyo"
//
//    func analyzeHealthData(_ metrics: [HealthMetric]) async throws -> [AIInsight] {
//
//        print("🧠 [LLM] Analyzing health data...")
//        print("📊 Metrics count: \(metrics.count)")
//
//        for metric in metrics {
//            print("➡️ \(metric.type.displayName): \(metric.value) \(metric.unit)")
//        }
//
//        let insights = metrics.map {
//            AIInsight(
//                title: $0.type.displayName,
//                summary: "Your \($0.type.displayName.lowercased()) is \(Int($0.value)) \($0.unit)",
//                generatedAt: Date()
//            )
//        }
//        
//        guard !metrics.isEmpty else {
//            return [AIInsight(
//                title: "No Data",
//                summary: "Using demo health data to show insights",
//                generatedAt: Date()
//            )]
//        }
//
//        print("✅ [LLM] Generated \(insights.count) insights")
//        return insights
//    }
//
//    func sendChatMessage(
//        _ message: String,
//        history: [ChatMessage],
//        insights: [AIInsight]
//    ) async throws -> ChatMessage {
//
//        let context = insights
//            .map { "\($0.title): \($0.summary)" }
//            .joined(separator: "\n")
//
//        let fullPrompt = """
//        You are a health assistant.
//
//        User health summary:
//        \(context)
//
//        User question:
//        \(message)
//        """
//
//        return ChatMessage(
//            text: generateMockAIResponse(from: fullPrompt),
//            isUser: false,
//            date: Date()
//        )
//    }
//    
//    private func generateMockAIResponse(from prompt: String) -> String {
//        let p = prompt.lowercased()
//
//        if p.contains("sleep") {
//            return "Your sleep duration looks fairly consistent, averaging around 6–8 hours. Try to maintain a regular sleep schedule for better recovery."
//        }
//
//        if p.contains("steps") {
//            return "Your daily steps are within a healthy range, but increasing consistency will help improve cardiovascular health."
//        }
//
//        if p.contains("heart") {
//            return "Your heart rate values are within a normal range. Regular exercise and stress management will help maintain heart health."
//        }
//
//        if p.contains("exercise") {
//            return "Your exercise minutes show good activity levels. Try to maintain at least 30 minutes of movement daily."
//        }
//
//        return "Based on your recent health data, you're doing well overall. Let me know if you want insights on sleep, activity, or heart rate."
//    }
//
//    
//}

// WITH REAL LLM API
final class GeminiService: LLMServiceProtocol {

    private let apiKey: String
    private let baseURL = "https://generativelanguage.googleapis.com" // put your LLM base url here
    private let model: String

    init(apiKey: String, model: String) {
        self.apiKey = apiKey
        self.model = model
    }

    // MARK: - Health Analysis (local fallback)
    func analyzeHealthData(_ metrics: [HealthMetric]) async throws -> [AIInsight] {
        guard !metrics.isEmpty else {
            return [
                AIInsight(
                    title: "No Data",
                    summary: "Using demo health data to show insights",
                    generatedAt: Date()
                )
            ]
        }

        return metrics.map {
            AIInsight(
                title: $0.type.displayName,
                summary: "Your \($0.type.displayName.lowercased()) is \(Int($0.value)) \($0.unit)",
                generatedAt: Date()
            )
        }
    }

    // MARK: - Chat with Gemini
    func sendChatMessage(
        _ message: String,
        history: [ChatMessage],
        insights: [AIInsight]
    ) async throws -> ChatMessage {

        let context = insights
            .map { "\($0.title): \($0.summary)" }
            .joined(separator: "\n")

        let prompt = """
        You are a health assistant AI.

        User health summary:
        \(context)

        User question:
        \(message)
        """

        let text = try await sendToGemini(prompt: prompt)

        return ChatMessage(text: text, isUser: false, date: Date())
    }

    // MARK: - Gemini API
    private func sendToGemini(prompt: String) async throws -> String {

        // URL & modal 
        let urlString = "\(baseURL)/v1beta/models/\(model):generateContent?key=\(apiKey)"
        guard let url = URL(string: urlString) else { throw URLError(.badURL) }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        // Payload
        let body: [String: Any] = [
            "contents": [
                [
                    "parts": [
                        ["text": prompt]
                    ]
                ]
            ]
        ]

        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, _) = try await URLSession.shared.data(for: request)

        // Debug raw response
        print("🧾 [Gemini RAW RESPONSE]")
        print(String(data: data, encoding: .utf8) ?? "no data")

        // API Response Parser Method
        let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]

        guard
            let candidates = json?["candidates"] as? [[String: Any]],
            let contentDict = candidates.first?["content"] as? [String: Any],
            let parts = contentDict["parts"] as? [[String: Any]],
            let text = parts.first?["text"] as? String
        else {
            throw NSError(
                domain: "Gemini",
                code: 0,
                userInfo: [NSLocalizedDescriptionKey: "Invalid Gemini response"]
            )
        }

        return text

        
    }
}
