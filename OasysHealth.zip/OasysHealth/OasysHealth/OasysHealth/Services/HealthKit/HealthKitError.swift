//
//  HealthKitError.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation

enum HealthKitError: Error, LocalizedError {
    case notAvailable
    case authorizationDenied
    case noData

    var errorDescription: String? {
        switch self {
        case .notAvailable:
            return "Health data is not available on this device."
        case .authorizationDenied:
            return "Health permissions were denied."
        case .noData:
            return "No health data available."
        }
    }
}
