//
//  HealthKitService.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation

final class HealthKitService {

    static let shared = HealthKitService()

    private let auth = HealthKitAuthorization.shared
    private let queries = HealthKitQueries()

    private init() {}

    func requestPermission() async throws {
        try await auth.requestAuthorization()
    }

    func fetchAllMetrics(days: Int) async throws -> [HealthMetric] {
        let end = Date()
        let start = Calendar.current.date(byAdding: .day, value: -days, to: end)!

        async let steps = queries.fetchSteps(from: start, to: end)
        async let heart = queries.fetchHeartRate(from: start, to: end)
        async let energy = queries.fetchActiveEnergy(from: start, to: end)
        async let exercise = queries.fetchExerciseMinutes(from: start, to: end)
        async let sleep = queries.fetchSleep(from: start, to: end)

        return try await (
            steps + heart + energy + exercise + sleep
        )
    }
}
