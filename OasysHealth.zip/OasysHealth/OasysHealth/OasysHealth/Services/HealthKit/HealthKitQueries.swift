//
//  HealthKitQueries.swift
//  OasysHealth
//
//  Created by ADIL RAMZAN on 19/01/2026.
//

import Foundation
import HealthKit

final class HealthKitQueries {

    private let healthStore = HKHealthStore()

    // MARK: - Steps
    func fetchSteps(from startDate: Date, to endDate: Date) async throws -> [HealthMetric] {
        let type = HKQuantityType.quantityType(forIdentifier: .stepCount)!
        return try await fetchQuantity(
            type: type,
            unit: .count(),
            metricType: .steps,
            startDate: startDate,
            endDate: endDate
        )
    }

    // MARK: - Heart Rate
    func fetchHeartRate(from startDate: Date, to endDate: Date) async throws -> [HealthMetric] {
        let type = HKQuantityType.quantityType(forIdentifier: .heartRate)!
        return try await fetchQuantity(
            type: type,
            unit: HKUnit.count().unitDivided(by: .minute()),
            metricType: .heartRate,
            startDate: startDate,
            endDate: endDate
        )
    }

    // MARK: - Active Energy
    func fetchActiveEnergy(from startDate: Date, to endDate: Date) async throws -> [HealthMetric] {
        let type = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned)!
        return try await fetchQuantity(
            type: type,
            unit: .kilocalorie(),
            metricType: .activeEnergy,
            startDate: startDate,
            endDate: endDate
        )
    }

    // MARK: - Exercise Minutes
    func fetchExerciseMinutes(from startDate: Date, to endDate: Date) async throws -> [HealthMetric] {
        let type = HKQuantityType.quantityType(forIdentifier: .appleExerciseTime)!
        return try await fetchQuantity(
            type: type,
            unit: .minute(),
            metricType: .exerciseMinutes,
            startDate: startDate,
            endDate: endDate
        )
    }

    // MARK: - Sleep
    func fetchSleep(from startDate: Date, to endDate: Date) async throws -> [HealthMetric] {
        let type = HKCategoryType.categoryType(forIdentifier: .sleepAnalysis)!

        return try await withCheckedThrowingContinuation { continuation in
            let predicate = HKQuery.predicateForSamples(
                withStart: startDate,
                end: endDate,
                options: .strictStartDate
            )

            let query = HKSampleQuery(
                sampleType: type,
                predicate: predicate,
                limit: HKObjectQueryNoLimit,
                sortDescriptors: nil
            ) { _, samples, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }

                let metrics: [HealthMetric] = (samples as? [HKCategorySample])?.compactMap {
                    let hours = $0.endDate.timeIntervalSince($0.startDate) / 3600
                    return HealthMetric(
                        type: .sleepHours,
                        value: hours,
                        date: $0.startDate,
                        unit: "hrs"
                    )
                } ?? []

                continuation.resume(returning: metrics)
            }

            healthStore.execute(query)
        }
    }

    // MARK: - Shared Quantity Fetcher
    private func fetchQuantity(
        type: HKQuantityType,
        unit: HKUnit,
        metricType: HealthMetricType,
        startDate: Date,
        endDate: Date
    ) async throws -> [HealthMetric] {

        try await withCheckedThrowingContinuation { continuation in
            let predicate = HKQuery.predicateForSamples(
                withStart: startDate,
                end: endDate,
                options: .strictStartDate
            )

            let query = HKSampleQuery(
                sampleType: type,
                predicate: predicate,
                limit: HKObjectQueryNoLimit,
                sortDescriptors: nil
            ) { _, samples, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }

                let metrics: [HealthMetric] = (samples as? [HKQuantitySample])?.map {
                    HealthMetric(
                        type: metricType,
                        value: $0.quantity.doubleValue(for: unit),
                        date: $0.startDate,
                        unit: metricType.unit
                    )
                } ?? []

                continuation.resume(returning: metrics)
            }

            healthStore.execute(query)
        }
    }
}
